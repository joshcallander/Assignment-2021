﻿
namespace Assignment_2021
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonRoll = new System.Windows.Forms.Button();
            this.buttonBuy = new System.Windows.Forms.Button();
            this.buttonDrawCard = new System.Windows.Forms.Button();
            this.buttonEndTurn = new System.Windows.Forms.Button();
            this.richTextBoxPlayerOne = new System.Windows.Forms.RichTextBox();
            this.richTextBoxPlayerTwo = new System.Windows.Forms.RichTextBox();
            this.richTextBoxPlayerThree = new System.Windows.Forms.RichTextBox();
            this.richTextBoxPlayerFour = new System.Windows.Forms.RichTextBox();
            this.richTextBoxPropertyDetails = new System.Windows.Forms.RichTextBox();
            this.textBoxDisplay = new System.Windows.Forms.TextBox();
            this.pictureBoxPlayerOne = new System.Windows.Forms.PictureBox();
            this.pictureBoxPlayerTwo = new System.Windows.Forms.PictureBox();
            this.pictureBoxPlayerThree = new System.Windows.Forms.PictureBox();
            this.pictureBoxPlayerFour = new System.Windows.Forms.PictureBox();
            this.timerScore = new System.Windows.Forms.Timer(this.components);
            this.pictureBoxCard = new System.Windows.Forms.PictureBox();
            this.panelGame = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayerOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayerTwo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayerThree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayerFour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCard)).BeginInit();
            this.panelGame.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonRoll
            // 
            this.buttonRoll.Location = new System.Drawing.Point(801, 12);
            this.buttonRoll.Name = "buttonRoll";
            this.buttonRoll.Size = new System.Drawing.Size(75, 23);
            this.buttonRoll.TabIndex = 1;
            this.buttonRoll.Text = "Roll";
            this.buttonRoll.UseVisualStyleBackColor = true;
            this.buttonRoll.Click += new System.EventHandler(this.buttonRoll_Click);
            // 
            // buttonBuy
            // 
            this.buttonBuy.Location = new System.Drawing.Point(932, 12);
            this.buttonBuy.Name = "buttonBuy";
            this.buttonBuy.Size = new System.Drawing.Size(75, 23);
            this.buttonBuy.TabIndex = 2;
            this.buttonBuy.Text = "Buy";
            this.buttonBuy.UseVisualStyleBackColor = true;
            this.buttonBuy.Click += new System.EventHandler(this.buttonBuy_Click);
            // 
            // buttonDrawCard
            // 
            this.buttonDrawCard.Location = new System.Drawing.Point(801, 63);
            this.buttonDrawCard.Name = "buttonDrawCard";
            this.buttonDrawCard.Size = new System.Drawing.Size(75, 23);
            this.buttonDrawCard.TabIndex = 3;
            this.buttonDrawCard.Text = "Draw Card";
            this.buttonDrawCard.UseVisualStyleBackColor = true;
            this.buttonDrawCard.Click += new System.EventHandler(this.buttonDrawCard_Click);
            // 
            // buttonEndTurn
            // 
            this.buttonEndTurn.Location = new System.Drawing.Point(932, 63);
            this.buttonEndTurn.Name = "buttonEndTurn";
            this.buttonEndTurn.Size = new System.Drawing.Size(75, 23);
            this.buttonEndTurn.TabIndex = 5;
            this.buttonEndTurn.Text = "End Turn";
            this.buttonEndTurn.UseVisualStyleBackColor = true;
            this.buttonEndTurn.Click += new System.EventHandler(this.buttonEndTurn_Click);
            // 
            // richTextBoxPlayerOne
            // 
            this.richTextBoxPlayerOne.Location = new System.Drawing.Point(802, 278);
            this.richTextBoxPlayerOne.Name = "richTextBoxPlayerOne";
            this.richTextBoxPlayerOne.ReadOnly = true;
            this.richTextBoxPlayerOne.Size = new System.Drawing.Size(100, 140);
            this.richTextBoxPlayerOne.TabIndex = 7;
            this.richTextBoxPlayerOne.Text = "";
            // 
            // richTextBoxPlayerTwo
            // 
            this.richTextBoxPlayerTwo.Location = new System.Drawing.Point(908, 278);
            this.richTextBoxPlayerTwo.Name = "richTextBoxPlayerTwo";
            this.richTextBoxPlayerTwo.ReadOnly = true;
            this.richTextBoxPlayerTwo.Size = new System.Drawing.Size(100, 140);
            this.richTextBoxPlayerTwo.TabIndex = 8;
            this.richTextBoxPlayerTwo.Text = "";
            // 
            // richTextBoxPlayerThree
            // 
            this.richTextBoxPlayerThree.Location = new System.Drawing.Point(801, 424);
            this.richTextBoxPlayerThree.Name = "richTextBoxPlayerThree";
            this.richTextBoxPlayerThree.ReadOnly = true;
            this.richTextBoxPlayerThree.Size = new System.Drawing.Size(100, 140);
            this.richTextBoxPlayerThree.TabIndex = 9;
            this.richTextBoxPlayerThree.Text = "";
            // 
            // richTextBoxPlayerFour
            // 
            this.richTextBoxPlayerFour.Location = new System.Drawing.Point(908, 424);
            this.richTextBoxPlayerFour.Name = "richTextBoxPlayerFour";
            this.richTextBoxPlayerFour.ReadOnly = true;
            this.richTextBoxPlayerFour.Size = new System.Drawing.Size(100, 140);
            this.richTextBoxPlayerFour.TabIndex = 10;
            this.richTextBoxPlayerFour.Text = "";
            // 
            // richTextBoxPropertyDetails
            // 
            this.richTextBoxPropertyDetails.Location = new System.Drawing.Point(802, 165);
            this.richTextBoxPropertyDetails.Name = "richTextBoxPropertyDetails";
            this.richTextBoxPropertyDetails.ReadOnly = true;
            this.richTextBoxPropertyDetails.Size = new System.Drawing.Size(100, 100);
            this.richTextBoxPropertyDetails.TabIndex = 11;
            this.richTextBoxPropertyDetails.Text = "";
            // 
            // textBoxDisplay
            // 
            this.textBoxDisplay.Location = new System.Drawing.Point(801, 121);
            this.textBoxDisplay.Multiline = true;
            this.textBoxDisplay.Name = "textBoxDisplay";
            this.textBoxDisplay.Size = new System.Drawing.Size(206, 20);
            this.textBoxDisplay.TabIndex = 12;
            // 
            // pictureBoxPlayerOne
            // 
            this.pictureBoxPlayerOne.BackgroundImage = global::Assignment_2021.Properties.Resources.jandal;
            this.pictureBoxPlayerOne.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxPlayerOne.Location = new System.Drawing.Point(687, 687);
            this.pictureBoxPlayerOne.Name = "pictureBoxPlayerOne";
            this.pictureBoxPlayerOne.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxPlayerOne.TabIndex = 6;
            this.pictureBoxPlayerOne.TabStop = false;
            // 
            // pictureBoxPlayerTwo
            // 
            this.pictureBoxPlayerTwo.BackgroundImage = global::Assignment_2021.Properties.Resources.sheep;
            this.pictureBoxPlayerTwo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxPlayerTwo.Location = new System.Drawing.Point(687, 687);
            this.pictureBoxPlayerTwo.Name = "pictureBoxPlayerTwo";
            this.pictureBoxPlayerTwo.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxPlayerTwo.TabIndex = 13;
            this.pictureBoxPlayerTwo.TabStop = false;
            // 
            // pictureBoxPlayerThree
            // 
            this.pictureBoxPlayerThree.BackgroundImage = global::Assignment_2021.Properties.Resources.surfboard;
            this.pictureBoxPlayerThree.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxPlayerThree.Location = new System.Drawing.Point(687, 687);
            this.pictureBoxPlayerThree.Name = "pictureBoxPlayerThree";
            this.pictureBoxPlayerThree.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxPlayerThree.TabIndex = 14;
            this.pictureBoxPlayerThree.TabStop = false;
            // 
            // pictureBoxPlayerFour
            // 
            this.pictureBoxPlayerFour.BackgroundImage = global::Assignment_2021.Properties.Resources.vegemite;
            this.pictureBoxPlayerFour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxPlayerFour.Location = new System.Drawing.Point(687, 687);
            this.pictureBoxPlayerFour.Name = "pictureBoxPlayerFour";
            this.pictureBoxPlayerFour.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxPlayerFour.TabIndex = 15;
            this.pictureBoxPlayerFour.TabStop = false;
            // 
            // timerScore
            // 
            this.timerScore.Enabled = true;
            this.timerScore.Interval = 1000;
            this.timerScore.Tick += new System.EventHandler(this.timerScore_Tick);
            // 
            // pictureBoxCard
            // 
            this.pictureBoxCard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxCard.Location = new System.Drawing.Point(907, 165);
            this.pictureBoxCard.Name = "pictureBoxCard";
            this.pictureBoxCard.Size = new System.Drawing.Size(100, 100);
            this.pictureBoxCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCard.TabIndex = 16;
            this.pictureBoxCard.TabStop = false;
            // 
            // panelGame
            // 
            this.panelGame.Controls.Add(this.pictureBoxPlayerFour);
            this.panelGame.Controls.Add(this.pictureBoxPlayerTwo);
            this.panelGame.Controls.Add(this.pictureBoxPlayerThree);
            this.panelGame.Controls.Add(this.pictureBoxPlayerOne);
            this.panelGame.Location = new System.Drawing.Point(0, 0);
            this.panelGame.Name = "panelGame";
            this.panelGame.Size = new System.Drawing.Size(785, 785);
            this.panelGame.TabIndex = 17;
            this.panelGame.Paint += new System.Windows.Forms.PaintEventHandler(this.panelGame_Paint);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 785);
            this.Controls.Add(this.pictureBoxCard);
            this.Controls.Add(this.textBoxDisplay);
            this.Controls.Add(this.richTextBoxPropertyDetails);
            this.Controls.Add(this.richTextBoxPlayerFour);
            this.Controls.Add(this.richTextBoxPlayerThree);
            this.Controls.Add(this.richTextBoxPlayerTwo);
            this.Controls.Add(this.richTextBoxPlayerOne);
            this.Controls.Add(this.buttonEndTurn);
            this.Controls.Add(this.buttonDrawCard);
            this.Controls.Add(this.buttonBuy);
            this.Controls.Add(this.buttonRoll);
            this.Controls.Add(this.panelGame);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form4";
            this.Text = "Form4";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayerOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayerTwo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayerThree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayerFour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCard)).EndInit();
            this.panelGame.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonEndTurn;
        private System.Windows.Forms.PictureBox pictureBoxPlayerOne;
        private System.Windows.Forms.RichTextBox richTextBoxPlayerOne;
        private System.Windows.Forms.RichTextBox richTextBoxPlayerTwo;
        private System.Windows.Forms.RichTextBox richTextBoxPlayerThree;
        private System.Windows.Forms.RichTextBox richTextBoxPlayerFour;
        private System.Windows.Forms.RichTextBox richTextBoxPropertyDetails;
        private System.Windows.Forms.PictureBox pictureBoxPlayerTwo;
        private System.Windows.Forms.PictureBox pictureBoxPlayerThree;
        private System.Windows.Forms.PictureBox pictureBoxPlayerFour;
        public System.Windows.Forms.Button buttonRoll;
        public System.Windows.Forms.Button buttonBuy;
        public System.Windows.Forms.Button buttonDrawCard;
        public System.Windows.Forms.Timer timerScore;
        public System.Windows.Forms.PictureBox pictureBoxCard;
        public System.Windows.Forms.TextBox textBoxDisplay;
        public System.Windows.Forms.Panel panelGame;
    }
}